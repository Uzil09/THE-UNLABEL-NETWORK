 const toggle = document.querySelector('.menu-toggle');
 const nav = document.getElementById('nav');
 toggle.addEventListener('click',() =>{
     const open = nav.classList.toggle('open');
     toggle.setAttribute('aria-expanded', open);
 }) 

 // FORM
const form = document.getElementById("form");
const result = document.getElementById("result");

form.addEventListener("submit", function (e) {
  e.preventDefault();
  const formData = new FormData(form);
  const object = Object.fromEntries(formData);
  const json = JSON.stringify(object);
  result.innerHTML = "Please wait......";

  fetch("https://api.web3forms.com/submmit", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: json,
  })
    .then(async (response) => {
      let json = await response.json();
      if (response.status == 200) {
        result.innerHTML = "Form submitted successfully";
      } else {
        console.log(response);
        result.innerHTML = json.message;
      }
    })
    .catch((error) => {
      console.log(error);
      result.innerHTML = "Something went wrong!";
    })
    .then(function () {
      form.requestFullscreen();
      setTimeout(() => {
        result.style.display = "none";
      }, 3000);
    });
});

